ServerEvents.recipes(event => {
        event.custom({
        type: "create:pressing",
        ingredients: [
        { "tag": "create:pulpifiable" },
       ],
        results: [
        { id: "minecraft:paper", count: 1 },
        ]

    })

    event.custom({
        type: "create:crushing",
        ingredients: [
        { item: "minecraft:quartz" }
        ],
        "processing_time": 250,
        results: [
        { id: "create:experience_nugget" },
        { id: "create:experience_nugget", chance: 0.20 },
        ]
    })

    event.custom({
        type: "create:compacting",
        ingredients: [
        { item: "tfmg:bitumen"},
        { item: "tfmg:bitumen"}
        ],
        results: [
        { id: "create:belt_connector", count: 4 },
        ]
    })

    event.custom({
        type: "create_dragons_plus:ending",
        ingredients: [
            { item: "minecraft:glass_bottle" }
        ],
        results: [
            { id: "minecraft:dragon_breath" }
        ]
    })

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:black_concrete" },
        loops: 1,
        results: [
            { id: "minecraft:dragon_head"},
        ],
        sequence:[
            {
                type: "create:filling",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                    { type: "neoforge:single", fluid: "create_enchantment_industry:experience", amount: 150 }
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                    { item: "minecraft:chorus_fruit" }
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                    { item: "minecraft:chorus_fruit" }
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
            {
                type: "create:filling",
                ingredients: [
                    { item: "minecraft:black_concrete" },
                    { type: "neoforge:single", fluid: "create_enchantment_industry:experience", amount: 150 }
                ],
                results: [
                    { id: "minecraft:black_concrete" }
                ]
            },
        ],
        transitional_item: { id: "minecraft:black_concrete" }
    })
})