ServerEvents.recipes(event => {
    event.remove({ type: 'create:crushing', input: 'minecraft:tuff' })
    event.custom({
    type: "create:crushing",
    ingredients: [
      { item: "minecraft:tuff" }
    ], 
    processingTime: 200,
    results: [
      { id: 'minecraft:flint', chance: 0.40 },
      { id: 'minecraft:gold_nugget', chance: 0.25 },
      { id: 'create:copper_nugget', chance: 0.25 },
      { id: 'create:zinc_nugget', chance: 0.25 },
      { id: 'minecraft:iron_nugget', chance: 0.25 },
    ]
  })

  event.remove({ output: 'minecraft:flint', type: 'create:splashing' })
    
    event.custom({
        type: "create:splashing",
        ingredients: [
            { item: "minecraft:gravel"},
        ],
        results: [
        { id: "minecraft:flint", chance: 0.35 },
        { id: "minecraft:iron_nugget", chance: 0.25 },
        ]

    })
})