ServerEvents.recipes(event => {
        // Re-add the removed casings
    event.custom({
        type: "create:item_application",
        ingredients: [
            { tag : "c:stripped_logs" },
            { item: "kubejs:radiance_alloy" }
        ],
        results: [
            { id: "create:refined_radiance_casing" }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { tag : "c:stripped_woods" },
            { item: "kubejs:radiance_alloy" }
        ],
        results: [
            { id: "create:refined_radiance_casing" }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { tag : "c:stripped_logs" },
            { item: "kubejs:shadow_steel_alloy" }
        ],
        results: [
            { id: "create:shadow_steel_casing" }
        ]
    })

    event.custom({
        type: "create:item_application",
        ingredients: [
            { tag : "c:stripped_woods" },
            { item: "kubejs:shadow_steel_alloy" }
        ],
        results: [
            { id: "create:shadow_steel_casing" }
        ]
    })

    // added the alloy recipes
    event.custom({
        type: "create:haunting",
        ingredients: [
            { item: "tfmg:steel_ingot"}
        ],
        results: [
            { id: "kubejs:shadow_steel_alloy" }
        ]
    })

    event.custom({
        type: "tfmg:casting",
        ingredients: [
            { type: "neoforge:single", fluid: "kubejs:molten_radiance", amount: 144 }
        ],
        "processing_time": 100,
        results: [
            { id: "kubejs:radiance_alloy" },
        ]
    })

    event.custom({
        type: "create:mixing",
        heat_requirement: "heated",
        ingredients: [
            { item: "kubejs:polished_quartz"},
            { item: "kubejs:polished_quartz"},
            { item: "kubejs:polished_quartz"},
            { item: "create:andesite_alloy"},
            { item: "create:andesite_alloy"},
            { item: "tfmg:aluminum_ingot"},
        ],
        results: [
            { id: "kubejs:molten_radiance", amount: 500 }
        ]

    })
})