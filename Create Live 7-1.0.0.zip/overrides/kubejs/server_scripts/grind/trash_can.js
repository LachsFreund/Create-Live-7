ServerEvents.recipes(event => {
    event.remove({ output: "refurbished_furniture:recycle_bin"})

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:iron_block" },
        loops: 2,
        results: [
            { id: "refurbished_furniture:recycle_bin" },
        ],
        sequence:[
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:iron_block" },
                    { item: "minecraft:iron_block" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:reinforced_iron_block" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:reinforced_iron_block" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "minecraft:iron_ingot" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:iron_plate" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:iron_plate" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:iron_plate" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:iron_plate" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "minecraft:iron_ingot" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "minecraft:iron_ingot" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:iron_rod" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "minecraft:iron_ingot" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "create:iron_sheet" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:compressed_compacted_iron_block" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "create:iron_sheet" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "kubejs:compressed_compacted_iron_block" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:bucket" },
                    { item: "create:iron_sheet" }
                ],
                results: [
                    { id: "minecraft:bucket" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "minecraft:bucket" }
                ],
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:bucket" },
                ],
                results: [
                    { id: "refurbished_furniture:recycle_bin" }
                ],
            },
        ],
        transitional_item: { id: "minecraft:bucket" }
    });
})