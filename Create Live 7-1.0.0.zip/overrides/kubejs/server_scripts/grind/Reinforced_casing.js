ServerEvents.recipes(event => {
    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:iron_ingot" },
        loops: 3,
        results: [
            { id: "kubejs:iron_rod", chance: 0.95 },
            { id: "minecraft:iron_nugget", chance: 0.1 }
        ],
        sequence:[
            {
                type: "create_enchantment_industry:grinding",
                ingredients: [
                    { item: "minecraft:iron_ingot" },
                ],
                results: [
                    { id: "minecraft:iron_ingot" }
                ]
            },
            {
                type: "create:deploying",
                keep_held_item: true,
                ingredients: [
                    { item: "minecraft:iron_ingot" },
                    { item: "createdieselgenerators:wire_cutters"}
                ],
                results: [
                    { id: "minecraft:iron_ingot" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_ingot" },
                ],
                results: [
                    { id: "kubejs:iron_rod" }
                ]
            }
        ],
        transitional_item: { id: "minecraft:iron_ingot" }
    });

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "kubejs:reinforced_iron_block" },
        loops: 10,
        results: [
            { id: "kubejs:reinforced_casing", chance: 0.7 },
            { id: "create:weathered_iron_block", chance: 0.3 },
        ],
        sequence:[
           {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:iron_block" },
                    { item: "kubejs:iron_rod"}
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:iron_block" },
                    { item: "kubejs:iron_plate"}
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:iron_block" },
                    { item: "powergrid:resistive_coil"}
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "minecraft:iron_block" }
                ]
            },
            {
                type: "create:filling",
                ingredients: [
                    { item: "minecraft:iron_block" },
                    { type: "neoforge:single", fluid: "minecraft:water", amount: 1000 }
                ],
                results: [
                    { id: "kubejs:reinforced_casing" }
                ]
            },
        ],
        transitional_item: { id: "minecraft:iron_block" }
    });

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:iron_block" },
        loops: 3,
        results: [
            { id: "kubejs:iron_plate", chance: 0.95 },
            { id: "create:iron_sheet", chance: 0.1 }
        ],
        sequence:[
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "create:iron_sheet" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "create:iron_sheet" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "minecraft:iron_block" },
                ],
                results: [
                    { id: "create:iron_sheet" }
                ]
            }
        ],
        transitional_item: { id: "create:iron_sheet" }
    });

    event.custom({
        type: "create:compacting",
        ingredients: [
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        { item: "minecraft:iron_block"},
        ],
        results: [
        { id: "kubejs:reinforced_iron_block"},
        ]
    })

    event.custom({
        type: "create:compacting",
        ingredients: [
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        { item: "kubejs:reinforced_iron_block"},
        ],
        results: [
        { id: "kubejs:compressed_compacted_iron_block"},
        ]
    })
})