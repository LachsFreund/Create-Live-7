ServerEvents.recipes(event => {
    event.remove({ id: "createdieselgenerators:crafting/oil_scanner" })
})