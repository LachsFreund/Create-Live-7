ServerEvents.recipes(event => {
   event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:amethyst_shard" },
        loops: 4,
        results: [
            { id: "minecraft:medium_amethyst_bud", chance: 0.6 },
            { id: "minecraft:amethyst_shard", chance: 0.4 }
        ],
        sequence:[
            {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:amethyst_shard" },
                    { item: "minecraft:amethyst_shard" }
                ],
                results: [
                    { id: "minecraft:amethyst_shard" }
                ]
            },
        ],
        transitional_item: { id: "minecraft:small_amethyst_bud" }
    });
    
    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "createdeco:andesite_sheet" },
        loops: 10,
        results: [
            { id: "kubejs:crystal_mechanism"},
        ],
        sequence:[
            {
                type: "create:deploying",
                ingredients: [
                    { item: "createdeco:andesite_sheet" },
                    { item: "minecraft:medium_amethyst_bud" }
                ],
                results: [
                    { id: "kubejs:incomplete_crystal_mechanism" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_crystal_mechanism" },
                    { item: "create:cogwheel" }
                ],
                results: [
                    { id: "kubejs:incomplete_crystal_mechanism" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_crystal_mechanism" },
                    { item: "create:large_cogwheel" }
                ],
                results: [
                    { id: "kubejs:incomplete_crystal_mechanism" }
                ]
            },
        ],
        transitional_item: { id: "kubejs:incomplete_crystal_mechanism" }
    });
})