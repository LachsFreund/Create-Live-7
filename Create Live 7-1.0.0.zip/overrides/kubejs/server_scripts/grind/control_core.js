ServerEvents.recipes((event) => {
    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "create:brass_sheet" },
        loops: 15,
        results: [
            { id: "kubejs:control_core" },
        ],
        sequence:[
            {
                type: "create:deploying",
                ingredients: [
                    { item: "create:brass_sheet" },
                    { item: "create:brass_ingot" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "kubejs:brass_plate" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "kubejs:brass_rod" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "kubejs:brass_plate" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:cogwheel" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:brass_nugget" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:large_cogwheel" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "kubejs:brass_rod" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:precision_mechanism" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:brass_hand" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                    { item: "create:brass_hand" }
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "kubejs:incomplete_control_core" },
                ],
                results: [
                    { id: "kubejs:incomplete_control_core" }
                ]
            },
        ],
        transitional_item: { id: "kubejs:incomplete_control_core" }
    });

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "create:brass_ingot" },
        loops: 3,
        results: [
            { id: "kubejs:brass_rod", chance: 0.95 },
            { id: "create:brass_nugget", chance: 0.1 }
        ],
        sequence:[
            {
                type: "create_enchantment_industry:grinding",
                ingredients: [
                    { item: "create:brass_ingot" },
                ],
                results: [
                    { id: "create:brass_ingot" }
                ]
            },
            {
                type: "create:deploying",
                keep_held_item: true,
                ingredients: [
                    { item: "create:brass_ingot" },
                    { item: "createdieselgenerators:wire_cutters"}
                ],
                results: [
                    { id: "create:brass_ingot" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "create:brass_ingot" },
                ],
                results: [
                    { id: "kubejs:brass_rod" }
                ]
            }
        ],
        transitional_item: { id: "create:brass_ingot" }
    });

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "create:brass_block" },
        loops: 3,
        results: [
            { id: "kubejs:brass_plate", chance: 0.95 },
            { id: "create:brass_sheet", chance: 0.1 }
        ],
        sequence:[
            {
                type: "create:pressing",
                ingredients: [
                    { item: "create:brass_block" },
                ],
                results: [
                    { id: "create:brass_sheet" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "create:brass_block" },
                ],
                results: [
                    { id: "create:brass_sheet" }
                ]
            },
            {
                type: "create:pressing",
                ingredients: [
                    { item: "create:brass_block" },
                ],
                results: [
                    { id: "create:brass_sheet" }
                ]
            }
        ],
        transitional_item: { id: "create:brass_sheet" }
    });
})