ServerEvents.recipes(event => {
    event.custom({
        type: "create:compacting",
        ingredients: [
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
            { item: "minecraft:dirt" },
        ],
        results: [
            { id: "kubejs:compressed_dirt" }
        ]
    })

    event.custom({
        type: "create_enchantment_industry:grinding",
        ingredients: [
            { item: "kubejs:compressed_dirt" },
        ],
        results: [
            { id: "kubejs:refined_dirt" }
        ]
    })

    event.custom({
        type: "create:compacting",
        ingredients: [
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
            { item: "kubejs:refined_dirt" },
        ],
        results: [
            { id: "kubejs:usable_dirt" }
        ]
    })

    event.custom({
        type: "create:filling",
        ingredients: [
            { item: "kubejs:usable_dirt" },
            { type: "neoforge:single", fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
            { id: "kubejs:cleansed_dirt" }
        ]
    })

    event.custom({
        type: "create:compacting",
        heat_requirement: "heated",
        ingredients: [
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
            { item: "kubejs:cleansed_dirt" },
        ],
        results: [
            { id: "kubejs:perfect_dirt" }
        ]
    })
})