ServerEvents.recipes(event => {
   event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:quartz" },
        loops: 5,
        results: [
            { id: "kubejs:polished_quartz", chance: 0.9 },
            { id: "create:experience_nugget", chance: 0.1 }
        ],
        sequence:[
            {
                type: "create_enchantment_industry:grinding",
                ingredients: [
                    { item: "minecraft:quartz" },
                ],
                results: [
                    { id: "minecraft:quartz" }
                ]
            },
           {
                type: "create:deploying",
                ingredients: [
                    { item: "minecraft:quartz" },
                    { tag: "create:sandpaper"}
                ],
                results: [
                    { id: "minecraft:quartz" }
                ]
            },
        ],
        transitional_item: { id: "minecraft:quartz" }
    });

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "minecraft:gold_block" },
        loops: 100,
        results: [
            { id: "minecraft:nether_star", components: { "minecraft:custom_data": { kubejs: "shop" } } },
        ],
        sequence:[
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:star_pattern" },
                    { item: "kubejs:polished_quartz"}
                ],
                results: [
                    { id: "kubejs:star_pattern" }
                ]
            },
           {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:star_pattern" },
                    { item: "minecraft:diamond"}
                ],
                results: [
                    { id: "kubejs:star_pattern" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "kubejs:star_pattern" },
                    { item: "kubejs:polished_quartz"}
                ],
                results: [
                    { id: "kubejs:star_pattern" }
                ]
            },
        ],
        transitional_item: { id: "kubejs:star_pattern" }
    });
})