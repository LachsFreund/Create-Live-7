ServerEvents.recipes((event) => {
    event.remove({ output: "refurbished_furniture:oak_chair" })

    event.custom({
        type: "create:deploying",
        ingredients: [
            { item: "minecraft:oak_planks" },
            { item: "minecraft:honeycomb_block"}
        ],
        keep_held_item: true,
        results: [
            { id: "kubejs:treated_oak_planks" }
        ]
    })
    
})