ServerEvents.recipes((event) => {
    event.remove({ id: "tfmg:mixing/gunpowder"})

    event.custom({
        type: "create:mixing",
        ingredients: [
            { item: "tfmg:nitrate_dust"},
            { item: "tfmg:nitrate_dust"},
            { item: "tfmg:nitrate_dust"},
            { item: "minecraft:charcoal"},
            { item: "minecraft:charcoal"},
            { item: "tfmg:sulfur_dust"}
        ],
        results: [
            { id: "minecraft:gunpowder", count: 9 }
        ]
    })

    // aluminum
    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "minecraft:red_sand"}
        ],
        processingTime: 200,
        results: [
            { id: "tfmg:bauxite_powder"},
            { id: "tfmg:bauxite_powder", chance: 0.25}
        ]
    })

    event.shaped(
        Item.of('tfmg:bauxite', 1), 
        [
            'AA',
            'AA',
        ],
        {
            A: 'tfmg:bauxite_powder'
        }
    )

    // lead
    event.remove({ id: "create:crushing/diorite"})
    event.remove({ id: "create:crushing/diorite_recycling"})

    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "minecraft:diorite"}
        ],
        processingTime: 200,
        results: [
            { id: "tfmg:galena"},
            { id: "tfmg:galena", chance: 0.25}
        ]
    })

    // nickel
    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "minecraft:basalt"}
        ],
        processingTime: 200,
        results: [
            { id: "create:crushed_raw_nickel", chance: 0.40},
            { id: "tfmg:nickel_nugget", chance: 0.10, count: 2},
        ]
    })

    // lithium
    event.shaped(
        Item.of('kubejs:salt_block', 1), 
        [
            'AAA',
            'AAA',
            'AAA'
        ],
        {
            A: 'ratatouille:salt'
        }
    )

    event.custom({
        type: "create:crushing",
        ingredients: [
            { item: "kubejs:salt_block"}
        ],
        processingTime: 200,
        results: [
            { id: "tfmg:crushed_raw_lithium", chance: 0.40},
            { id: "tfmg:lithium_nugget", chance: 0.10, count: 2},
        ]
    })

    // sulfur
    event.custom({
        type: "create:mixing",
        heat_requirement: "heated",
        ingredients: [
            { item: "minecraft:clay"},
            { item: "minecraft:clay"},
            { type: "neoforge:single", fluid: "minecraft:water", amount: 1000 }
        ],
        results: [
            { id: "tfmg:sulfur_dust", count: 3 }
        ]

    })

    event.shaped(
        Item.of('tfmg:sulfur', 1), 
        [
            'AA',
            'AA',
        ],
        {
            A: 'tfmg:sulfur_dust'
        }
    )
})