ServerEvents.recipes(event => {
    event.remove({ id: "createdieselgenerators:distillation/superheated_crude_oil" })
    event.remove({ id: "createdieselgenerators:distillation/crude_oil" })

    event.remove({ id: "tfmg:asphalt_wall_from_asphalt_stonecutting" })
    event.remove({ id: "tfmg:asphalt_slab_from_asphalt_stonecutting" })
    event.remove({ id: "tfmg:asphalt_stairs_from_asphalt_stonecutting" })
    event.remove({ id: "tfmg:casting/plastic_sheet" })
    
    event.shaped(
        Item.of('minecraft:shulker_shell', 1), 
        [
            'AAA',
            'A A'
        ],
        {
            A: 'minecraft:popped_chorus_fruit'
        }
    )

    event.custom({
        type: "create:sequenced_assembly",
        ingredient: { item: "create:empty_blaze_burner" },
        loops: 1,
        results: [
            { id: "create:blaze_burner" }
        ],
        sequence:[
            {
                type: "create:filling",
                ingredients: [
                    { item: "create:empty_blaze_burner" },
                    { type: "neoforge:single", fluid: "minecraft:lava", amount: 1000 }
                ],
                results: [
                    { id: "create:empty_blaze_burner" }
                ]
            },
            {
                type: "create:deploying",
                ingredients: [
                    { item: "create:empty_blaze_burner" },
                    { item: "minecraft:gunpowder" }
                ],
                results: [
                    { id: "create:empty_blaze_burner" }
                ]
            },
        ],
        transitional_item: { id: "create:empty_blaze_burner" }
    });

    // fixed the 200mb
    event.custom({
        type: "tfmg:casting",
        ingredients: [
        { type: "neoforge:single", fluid: "tfmg:molten_plastic", amount: 144 }
        ],
        "processing_time": 100,
        results: [
        { id: "tfmg:plastic_sheet" },
        ]
    })
})
