Ponder.registry((event) => {
    event.remove('create:experience_nugget')
    event.remove('create_enchantment_industry:experience_hatch')

    event.create('create_enchantment_industry:super_experience_block')
        .scene('lightning_upgrade', '3x3 experience blocks struck by lightning', (scene, util) => {
            const T = 20;
            scene.showBasePlate();

            // place a 3x3 of experience blocks at y=1 (from x=0..2, z=0..2)
            scene.world.setBlocks([0, 1, 0, 2, 1, 2], 'create:experience_block', true);

            // place a lightning rod at the center on top
            scene.world.setBlock([1, 2, 1], 'minecraft:lightning_rod', true);

            // reveal the blocks and the rod so they become visible in the scene
            scene.world.showSection([0, 1, 0, 2, 2, 2], Facing.DOWN);
            scene.world.showSection([1, 2, 1], Facing.DOWN);

            scene.idle(10);

            // spawn a lightning bolt at the center above the rod
            scene.world.createEntity('lightning_bolt', [1.5, 2.5, 1.5]);

            scene.idle(10);

            // change the 3x3 experience blocks to the super experience block
            scene.world.setBlocks([0, 1, 0, 2, 1, 2], 'create_enchantment_industry:super_experience_block', true);

            scene.idle(20);
        });
});