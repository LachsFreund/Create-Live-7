StartupEvents.modifyCreativeTab('create_enchantment_industry:base', event => {
    event.remove("create:experience_nugget")
})
StartupEvents.modifyCreativeTab('createdieselgenerators:cdg_creative_tab', event => {
    event.remove("createdieselgenerators:diesel_engine")
    event.remove("createdieselgenerators:large_diesel_engine")
})

StartupEvents.modifyCreativeTab('tfmg:tfmg_decoration', event => {
    event.remove("tfmg:asphalt")
    event.remove("tfmg:asphalt_wall")
    event.remove("tfmg:asphalt_slab")
    event.remove("tfmg:asphalt_stairs")
})

StartupEvents.modifyCreativeTab('dndecor:base', event => {
    event.remove("dndecor:lead_cross_bolt")
    event.remove("dndecor:lead_dash_bolt")
    event.remove("dndecor:lead_dot_bolt")
    event.remove("dndecor:lead_flat_bolt")
    event.remove("dndecor:aluminum_cross_bolt")
    event.remove("dndecor:aluminum_dash_bolt")
    event.remove("dndecor:aluminum_dot_bolt")
    event.remove("dndecor:aluminum_flat_bolt")
    event.remove("dndecor:nickel_cross_bolt")
    event.remove("dndecor:nickel_dash_bolt")
    event.remove("dndecor:nickel_dot_bolt")
    event.remove("dndecor:nickel_flat_bolt")
    event.remove("dndecor:steel_cross_bolt")
    event.remove("dndecor:steel_dash_bolt")
    event.remove("dndecor:steel_dot_bolt")
    event.remove("dndecor:steel_flat_bolt")
    event.remove("dndecor:cast_iron_cross_bolt")
    event.remove("dndecor:cast_iron_dash_bolt")
    event.remove("dndecor:cast_iron_dot_bolt")
    event.remove("dndecor:cast_iron_flat_bolt")
})

StartupEvents.modifyCreativeTab('create_connected:main', event => {
    event.remove("create_connected:item_silo")
})

StartupEvents.modifyCreativeTab("refurbished_furniture:creative_tab", event => {
    event.remove("refurbished_furniture:workbench")
})

StartupEvents.modifyCreativeTab("minecraft:search", event => {
    event.add("create:refined_radiance_casing")
    event.add("create:shadow_steel_casing")
})

StartupEvents.modifyCreativeTab("kubejs:tab", event => {
    event.add("create:refined_radiance_casing")
    event.add("create:shadow_steel_casing")
})

StartupEvents.registry('item', event => {
    event.create('iron_rod')
    event.create('iron_plate')
    event.create("brass_rod")
    event.create("brass_plate")
    event.create("control_core")
    event.create("incomplete_control_core", "create:sequenced_assembly")
    event.create("crystal_mechanism")
    event.create("incomplete_crystal_mechanism", "create:sequenced_assembly")
    event.create("polished_quartz")
    event.create("star_pattern", "create:sequenced_assembly")
    event.create("shadow_steel_alloy")
    event.create("radiance_alloy")
})

StartupEvents.registry('block', event => {
    event.create('reinforced_casing')
    event.create("reinforced_iron_block")
    event.create("compressed_compacted_iron_block")
    event.create("salt_block")

    event.create("treated_oak_planks")

    event.create("unbreakable_industrial_iron_block")
        .hardness(-1.0)
        .resistance(3600000.0)

    event.create("compressed_dirt")
        .soundType("gravel")
    event.create("usable_dirt")
        .soundType("gravel")
    event.create("refined_dirt")
        .soundType("gravel")
    event.create("cleansed_dirt")
        .soundType("gravel")
    event.create("perfect_dirt")
        .soundType("gravel")
})

StartupEvents.registry('fluid', event => {
    event.create("molten_radiance", "thick")
        .tint(0xdedede)
})